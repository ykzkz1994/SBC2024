const AddPage = () => {
    return (
        <div>
            Camper Add page
        </div>
    );
}

export default AddPage;