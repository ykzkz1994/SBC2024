import ResGuideComponent from "../../components/campingRes/ResGuideComponent";

const ResGuidePage = () => {
    return (
        <div>
            <ResGuideComponent></ResGuideComponent>
        </div>
    );
};

export default ResGuidePage;
