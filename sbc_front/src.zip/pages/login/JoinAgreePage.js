import JoinAgreeComponent from "../../components/member/JoinAgreeComponent";

const JoinAgreePage = () => {
    return(
        <div>
            <JoinAgreeComponent/>
        </div>
    )
}

export default JoinAgreePage;