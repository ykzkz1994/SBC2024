import MemberInfoPage from "../../components/member/mypageMyInfoComponent";

const MypageMemberInfoPage = () => {
    return(
        <MemberInfoPage/>
    )
}

export default MypageMemberInfoPage;