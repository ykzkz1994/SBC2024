package com.sbcamping.user.reservation.dto;

import lombok.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class MemberDTO {

    private Long memberId;
}
