package com.sbcamping.user.reservation.dto;

import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SiteDTO {

    private Long siteId;

}
